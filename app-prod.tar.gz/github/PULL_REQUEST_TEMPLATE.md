Title: <concise summary>

Changes
- 

Motivation
- 

Testing
- How did you test (unit/integration/manual)?

Checklist
- [ ] CI green
- [ ] Docs updated if needed
- [ ] No breaking changes without migration notes


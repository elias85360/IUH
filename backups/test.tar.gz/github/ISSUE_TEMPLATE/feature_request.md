---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] <title>"
labels: enhancement
assignees: ''
---

Goal
- What problem does this feature solve?

Scope
- User stories / acceptance criteria

Notes
- Screenshots, references, or related issues


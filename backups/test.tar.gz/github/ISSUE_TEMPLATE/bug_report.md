---
name: Bug report
about: Create a report to help us improve
title: "[Bug] <title>"
labels: bug
assignees: ''
---

Steps to reproduce
1. 

Expected vs actual

Environment
- Frontend/Backend version, browser, OS

Logs
- Console/network logs, server logs if relevant

